const {
  addNewEtymology,
  getAllEtymologys,
  getEtymologyById,
  deleteEtymologyById,
  getEtymologysByEtymology,
} = require("../controllers/etymology.controller");

const router = require("express").Router();

router.post("/", addNewEtymology);
router.get("/search", getEtymologysByEtymology);
router.get("/", getAllEtymologys);
router.get("/:id", getEtymologyById);
router.delete("/:id", deleteEtymologyById);

module.exports = router;
