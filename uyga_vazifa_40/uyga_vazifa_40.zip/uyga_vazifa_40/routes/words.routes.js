const {
  addNewWord,
  getAllWords,
  deleteWordById,
  getWordsByWord,
  getWordById,
} = require("../controllers/words.controller");

const router = require("express").Router();

router.post("/", addNewWord);
router.get("/", getAllWords);
router.get("/search", getWordsByWord);
router.get("/:id", getWordById);
router.delete("/:id", deleteWordById);

module.exports = router;
