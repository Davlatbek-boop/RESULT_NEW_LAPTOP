const router = require("express").Router();

const wordsRoute = require("./words.routes");
const usersRoute = require("./users.routes");
const languageRoute = require("./language.routes");
const etymologyRoute = require("./Etymology.routes");
const pronunciationRoute = require("./pronunciation.routes");

router.use("/words", wordsRoute);
router.use("/users", usersRoute);
router.use("/language", languageRoute);
router.use("/etymology", etymologyRoute);
router.use("/pronunciation", pronunciationRoute);

module.exports = router;
