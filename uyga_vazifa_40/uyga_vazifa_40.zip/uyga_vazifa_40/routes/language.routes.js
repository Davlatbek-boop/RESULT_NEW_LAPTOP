const {
  addNewLanguage,
  getAllLanguages,
  getLanguageById,
  deleteLanguageById,
  getLanguagesByLanguage,
} = require("../controllers/languages.controller");

const router = require("express").Router();

router.post("/", addNewLanguage);
router.get("/search", getLanguagesByLanguage);
router.get("/", getAllLanguages);
router.get("/:id", getLanguageById);
router.delete("/:id", deleteLanguageById);

module.exports = router;
