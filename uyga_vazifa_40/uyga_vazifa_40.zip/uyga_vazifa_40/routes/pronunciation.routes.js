const {
  addNewPronunciation,
  getAllPronunciations,
  getPronunciationById,
  deletePronunciationById,
  getPronunciationsByPronunciation,
} = require("../controllers/pronunciation.controller");

const router = require("express").Router();

router.post("/", addNewPronunciation);
router.get("/search", getPronunciationsByPronunciation);
router.get("/", getAllPronunciations);
router.get("/:id", getPronunciationById);
router.delete("/:id", deletePronunciationById);

module.exports = router;
