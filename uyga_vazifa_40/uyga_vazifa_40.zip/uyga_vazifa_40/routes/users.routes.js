const {
  addNewUser,
  getAllUsers,
  getUserById,
  deleteUserById,
  getUsersByUser,
} = require("../controllers/users.controller");

const router = require("express").Router();

router.post("/", addNewUser);
router.get("/search", getUsersByUser);
router.get("/", getAllUsers);
router.get("/:id", getUserById);
router.delete("/:id", deleteUserById);

module.exports = router;
